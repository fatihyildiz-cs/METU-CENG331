/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_179()
{
    return 3286206792U;
}

unsigned getval_499()
{
    return 2447345992U;
}

unsigned addval_226(unsigned x)
{
    return x + 2428645704U;
}

void setval_145(unsigned *p)
{
    *p = 3286206792U;
}

unsigned addval_310(unsigned x)
{
    return x + 3284568392U;
}

unsigned getval_451()
{
    return 3284283712U;
}

void setval_407(unsigned *p)
{
    *p = 2428645704U;
}

unsigned addval_440(unsigned x)
{
    return x + 2425393241U;
}

unsigned addval_409(unsigned x)
{
    return x + 3364440156U;
}

unsigned addval_447(unsigned x)
{
    return x + 3284566344U;
}

void setval_200(unsigned *p)
{
    *p = 3330886851U;
}

unsigned addval_421(unsigned x)
{
    return x + 3351808328U;
}

unsigned addval_470(unsigned x)
{
    return x + 3284240456U;
}

void setval_173(unsigned *p)
{
    *p = 3284240712U;
}

void setval_214(unsigned *p)
{
    *p = 2462200136U;
}

unsigned getval_445()
{
    return 2431879496U;
}

unsigned addval_328(unsigned x)
{
    return x + 2431879432U;
}

unsigned getval_287()
{
    return 3281031257U;
}

unsigned getval_221()
{
    return 3353315656U;
}

unsigned addval_486(unsigned x)
{
    return x + 3284240744U;
}

unsigned addval_432(unsigned x)
{
    return x + 2431846728U;
}

unsigned addval_161(unsigned x)
{
    return x + 2462615880U;
}

void setval_391(unsigned *p)
{
    *p = 3287517512U;
}

void setval_177(unsigned *p)
{
    *p = 3330885803U;
}

unsigned addval_417(unsigned x)
{
    return x + 3284699464U;
}

unsigned getval_383()
{
    return 2423879632U;
}

void setval_205(unsigned *p)
{
    *p = 3284240712U;
}

void setval_102(unsigned *p)
{
    *p = 2425393497U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
